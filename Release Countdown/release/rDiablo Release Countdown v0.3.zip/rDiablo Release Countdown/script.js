$(document).ready(function () {
	var releaseDate = new Date('15 May 2012');
	$('.titlebox .usertext-body .md p:contains(Release Date:):first').append('<div id="countdown"></div>');
	$('#countdown').countdown({ until: releaseDate, compact: true, format: 'dHMS', timezone: -7 });
});