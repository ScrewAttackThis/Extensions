$(document).ready(function () {
	var releaseDate = new Date('15 May 2012');
	$('.titlebox .usertext-body .md p:eq(2)').append('<div id="countdown" class="countdown"></div>');
	$('#countdown').countdown({ until: releaseDate, compact: true, format: 'dHMS', timezone: -7 });
});