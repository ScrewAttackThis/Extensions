$('html').attr('lang', 'dd');

$(document).ready(function(){
	$('div.side div.usertext-body .md a[href="http://www.reddit.com/r/Diablo"]').click(function(e){
		e.preventDefault();
		$('html').attr('lang', 'en-us');
	});
	$('div.side div.usertext-body .md a[href="http://dd.reddit.com/r/Diablo"]').click(function(e){
		e.preventDefault();
		$('html').attr('lang', 'dd');
	});
});