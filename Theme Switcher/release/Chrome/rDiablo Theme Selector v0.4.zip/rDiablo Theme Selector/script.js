try {
	var theme = localStorage.getItem('theme');

	if (theme == null) {
		changeTheme('en-us');
	} else {
		changeTheme(theme);
	}
} catch (e) {
	alert(e.Message);
}

$(document).ready(function () {
	$('div.side div.usertext-body .md a[href="http://www.reddit.com/r/Diablo"]').click(function (e) {
		e.preventDefault();
		changeTheme('en-us');
	});
	$('div.side div.usertext-body .md a[href="http://dd.reddit.com/r/Diablo"]').click(function (e) {
		e.preventDefault();
		changeTheme('dd');
	});
});

function changeTheme(themeName)
{
	try {
		$('html').attr('lang', themeName);
		localStorage.removeItem('theme');
		localStorage.setItem('theme', themeName);
	}
	catch (e) {
		alert(e.Message);
	}
}